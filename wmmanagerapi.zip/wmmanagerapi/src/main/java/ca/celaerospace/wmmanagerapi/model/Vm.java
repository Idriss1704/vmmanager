package ca.celaerospace.wmmanagerapi.model;


import jakarta.validation.constraints.NotNull;
import lombok.*;
import org.springframework.data.annotation.*;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.Instant;
import java.util.LinkedHashSet;
import java.util.Set;

@Document
@Builder
@Getter @Setter
@NoArgsConstructor @AllArgsConstructor
public class Vm {

    @Id
    private String vmId;

    @NotNull
    private String name;

    private String status;

    private Integer cpu;

    private Integer memoryMb;

    private Integer diskGb;

    private String os;

    private String ip;

    @CreatedDate
    private Instant createdAt;

    @LastModifiedDate
    private Instant updatedAt;

    @Reference
    private Host host;

    @Reference
    private Set<AppUser> owners;

    @Reference
    private Set<UserGroup> ownerGroups;
}
