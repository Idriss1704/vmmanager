package ca.celaerospace.wmmanagerapi.model;

import jakarta.validation.constraints.NotNull;
import lombok.*;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.Instant;

@Document
@Getter @Setter @NoArgsConstructor @AllArgsConstructor
public class Host {

    @Id
    private String hostId;

    @NotNull
    @Indexed(unique = true)
    private String name;

    private String fqdnOrIp;

    private String domain;

    private boolean useDefaultCredentials = false;

    private String username;

    private String password;

    @CreatedDate
    private Instant createdAt;

    @LastModifiedDate
    private Instant updatedAt;

}
