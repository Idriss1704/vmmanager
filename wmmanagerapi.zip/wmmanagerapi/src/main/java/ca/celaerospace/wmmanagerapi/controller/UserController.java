package ca.celaerospace.wmmanagerapi.controller;

import ca.celaerospace.wmmanagerapi.dto.CustomDTOs;
import ca.celaerospace.wmmanagerapi.dto.Role;
import ca.celaerospace.wmmanagerapi.model.AppUser;
import ca.celaerospace.wmmanagerapi.model.UserGroup;
import ca.celaerospace.wmmanagerapi.repository.UserGroupRepository;
import ca.celaerospace.wmmanagerapi.repository.UserRepository;
import ca.celaerospace.wmmanagerapi.util.Util;
import lombok.AllArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/users")
@AllArgsConstructor
public class UserController {


    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final UserGroupRepository userGroupRepository;


    @GetMapping("/all")
    public List<AppUser> getAllUsers() {
        return userRepository.findAll();
    }


    @GetMapping("/{id}")
    public ResponseEntity<AppUser> getUserById(@PathVariable String id) {
        Optional<AppUser> user = userRepository.findByUserId(id);
        return user.map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    @GetMapping("/{id}/assign/group/{name}")
    public ResponseEntity<AppUser> addGroupToUser(@PathVariable String id, @PathVariable String name) {
        AppUser appUser = userRepository.findByUserId(id).orElseThrow();
        UserGroup group = userGroupRepository.findByGroupName(name).orElseThrow();
        appUser.getUserGroups().add(group);
        return ResponseEntity.ok(userRepository.save(appUser));
    }


    @GetMapping("/username/{username}")
    public ResponseEntity<AppUser> getUserByUsername(@PathVariable String username) {
        AppUser appUser = userRepository.findByUsername(username).orElseThrow();
        return ResponseEntity.ok(appUser);
    }


    @PostMapping("/register")
    @PreAuthorize("hasRole('ADMIN')")
    public CustomDTOs.ResponseUserDTO register(@RequestBody CustomDTOs.CreateUserDTO userDTO) {
        String encodedPassword = passwordEncoder.encode(userDTO.password());
        List<UserGroup> userGroups = userGroupRepository.findByGroupNameIn(userDTO.groupNames());
        AppUser user = AppUser.builder()
                .username(userDTO.username())
                .fullName(userDTO.fullName())
                .password(encodedPassword)
                .role(Role.valueOf(userDTO.role()))
                .userGroups(userGroups)
                .build();
        AppUser saved = userRepository.save(user);
        return CustomDTOs.ResponseUserDTO.builder()
                .id(saved.getUserId())
                .username(saved.getUsername())
                .fullName(saved.getFullName())
                .groupNames(Util.getGroupNamesFromGroups(saved.getUserGroups()))
                .roleName(saved.getRole().toString())
                .build();
    }

    @PostMapping("/list/register")
    @PreAuthorize("hasRole('ADMIN')")
    public void registerList(@RequestBody List<CustomDTOs.CreateUserDTO> userDTOs) {
        for (CustomDTOs.CreateUserDTO userDTO : userDTOs) {
            List<UserGroup> userGroups = userGroupRepository.findByGroupNameIn(userDTO.groupNames());
            String encodedPassword = passwordEncoder.encode(userDTO.password());
            AppUser user = AppUser.builder()
                    .username(userDTO.username())
                    .fullName(userDTO.fullName())
                    .password(encodedPassword)
                    .role(Role.valueOf(userDTO.role()))
                    .userGroups(userGroups)
                    .build();
            userRepository.save(user);
        }
    }

    @PostMapping("/update")
    public CustomDTOs.ResponseUserDTO update(@RequestBody CustomDTOs.UpdateUserDTO userDTO) {
        AppUser foundUser = userRepository.findByUsername(userDTO.username()).orElseThrow();
        List<UserGroup> userGroups = userGroupRepository.findByGroupNameIn(userDTO.groupNames());
        String encodedPassword = foundUser.getPassword();
        if (!userDTO.password().isBlank()) {
            encodedPassword = passwordEncoder.encode(userDTO.password());
        }
        AppUser user = AppUser.builder()
                .userId(foundUser.getUserId())
                .username(userDTO.username())
                .fullName(userDTO.fullName())
                .password(encodedPassword)
                .role(Role.valueOf(userDTO.role()))
                .userGroups(userGroups)
                .build();
        AppUser saved = userRepository.save(user);
        return CustomDTOs.ResponseUserDTO.builder()
                .username(saved.getUsername())
                .fullName(saved.getFullName())
                .groupNames(Util.getGroupNamesFromGroups(saved.getUserGroups()))
                .roleName(saved.getRole().toString())
                .build();
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<Void> deleteUser(@PathVariable String id) {
        if (!userRepository.existsByUserId(id)) {
            return ResponseEntity.notFound().build();
        }
        userRepository.deleteByUserId(id);
        return ResponseEntity.noContent().build();
    }
}
