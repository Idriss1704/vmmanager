package ca.celaerospace.wmmanagerapi.controller;

import ca.celaerospace.wmmanagerapi.model.Host;
import ca.celaerospace.wmmanagerapi.model.Vm;
import ca.celaerospace.wmmanagerapi.repository.HostRepository;
import ca.celaerospace.wmmanagerapi.services.HyperVService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/hosts")
@RequiredArgsConstructor
public class HostController {

    private final HostRepository hostRepository;
    private final HyperVService hyperVService;

    public record HostView(
            String hostId,
            String name,
            String fqdnOrIp,
            boolean useDefaultCredentials,
            String username
    ) {
        public static HostView of(Host h) {
            return new HostView(
                    h.getHostId(),
                    h.getName(),
                    h.getFqdnOrIp(),
                    h.isUseDefaultCredentials(),
                    h.getUsername()
            );
        }
    }

    @GetMapping("all")
    @Transactional(readOnly = true)
    public List<HostView> listAll() {
        return hostRepository.findAll().stream().map(HostView::of).toList();
    }

    @GetMapping("/{id}")
    @Transactional(readOnly = true)
    public ResponseEntity<HostView> getById(@PathVariable String id) {
        Optional<Host> host = hostRepository.findByHostId(id);
        return host.map(h -> ResponseEntity.ok(HostView.of(h)))
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    @GetMapping("/name/{name}")
    @Transactional(readOnly = true)
    public ResponseEntity<HostView> getByName(@PathVariable String name) {
        Host host = hostRepository.findByName(name);
        return (host == null) ? ResponseEntity.notFound().build()
                : ResponseEntity.ok(HostView.of(host));
    }

    @PostMapping("/register")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<HostView> create(@RequestBody Host payload) {
        if (payload.getHostId() != null && hostRepository.existsByHostId(payload.getHostId())) {
            return ResponseEntity.status(HttpStatus.CONFLICT).build();
        }
        if (payload.getName() != null && hostRepository.findByName(payload.getName()) != null) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).build(); // duplicate name
        }
        Host saved = hostRepository.save(payload);
        return ResponseEntity.status(HttpStatus.CREATED).body(HostView.of(saved));
    }

    @PutMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<HostView> update(@PathVariable String id, @RequestBody Host payload) {
        Optional<Host> opt = hostRepository.findByHostId(id);
        if (opt.isEmpty()) return ResponseEntity.notFound().build();

        Host h = opt.get();

        if (payload.getName() != null && !payload.getName().equals(h.getName())) {
            Host existing = hostRepository.findByName(payload.getName());
            if (existing != null && !existing.getHostId().equals(id)) {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
            }
            h.setName(payload.getName());
        }

        if (payload.getFqdnOrIp() != null) h.setFqdnOrIp(payload.getFqdnOrIp());
        h.setUseDefaultCredentials(payload.isUseDefaultCredentials());
        if (payload.getUsername() != null) h.setUsername(payload.getUsername());

        if (payload.getPassword() != null && !payload.getPassword().isBlank()) {
            h.setPassword(payload.getPassword());
        }

        Host saved = hostRepository.save(h);
        return ResponseEntity.ok(HostView.of(saved));
    }


    @DeleteMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<Void> delete(@PathVariable String id) {
        if (!hostRepository.existsByHostId(id)) {
            return ResponseEntity.notFound().build();
        }
        hostRepository.deleteByHostId(id);
        return ResponseEntity.noContent().build();
    }

    // ========== LIVE OPS ==========
    /**
     * Enumerate all VMs on a host using Hyper-V (transient VM objects, not persisted).
     */
    @GetMapping("/{id}/vms")
    @Transactional(readOnly = true)
    public ResponseEntity<List<Vm>> listVmsOnHost(@PathVariable String id) {
        Optional<Host> opt = hostRepository.findByHostId(id);
        if (opt.isEmpty()) return ResponseEntity.notFound().build();

        Host host = opt.get();
        return ResponseEntity.ok(hyperVService.listHostVmsAsync(host));
    }


}
