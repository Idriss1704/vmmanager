package ca.celaerospace.wmmanagerapi.dto;

public enum Role {
    ROLE_USER,
    ROLE_ADMIN
}