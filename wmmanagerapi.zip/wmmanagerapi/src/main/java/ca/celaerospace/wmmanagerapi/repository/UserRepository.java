package ca.celaerospace.wmmanagerapi.repository;

import ca.celaerospace.wmmanagerapi.model.AppUser;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.Optional;

public interface UserRepository extends MongoRepository<AppUser, Integer> {

    Optional<AppUser> findByUsername(String username);

    boolean existsByUserId(String id);

    boolean existsByUsername(String username);

    void deleteByUsername(String username);

    void deleteByUserId(String userId);

    Optional<AppUser> findByUserId(String id);
}