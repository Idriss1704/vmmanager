package ca.celaerospace.wmmanagerapi.controller;

import ca.celaerospace.wmmanagerapi.dto.CustomDTOs;
import ca.celaerospace.wmmanagerapi.model.AppUser;
import ca.celaerospace.wmmanagerapi.model.UserGroup;
import ca.celaerospace.wmmanagerapi.model.Vm;
import ca.celaerospace.wmmanagerapi.repository.UserGroupRepository;
import ca.celaerospace.wmmanagerapi.repository.UserRepository;
import ca.celaerospace.wmmanagerapi.repository.VmRepository;
import ca.celaerospace.wmmanagerapi.services.VmService;
import ca.celaerospace.wmmanagerapi.services.HyperVService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import java.time.Instant;
import java.util.*;
import java.util.stream.Collectors;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/vms")
public class VmController {

    private final VmRepository vmRepository;
    private final UserRepository userRepository;
    private final UserGroupRepository userGroupRepository;
    private final HyperVService hyperVService;
    private final VmService vmService;

    @GetMapping("/health")
    public Map<String, Object> health() {
        return Map.of("ok", true, "ts", Instant.now());
    }

    @GetMapping("/db/update")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<Boolean> updateVmListOnDB() {
        vmService.updateVmListOnDB();
        return ResponseEntity.ok(true);
    }

    @GetMapping("{id}/assign/user/{username}")
    public void assignUserToVm(@PathVariable String id, @PathVariable String username) {
        Vm vm = vmRepository.findByVmId(id).orElseThrow();
        AppUser appUser = userRepository.findByUsername(username).orElseThrow();
        vm.getOwners().add(appUser);
        vmRepository.save(vm);
    }

    @PostMapping("{id}/assignments")
    public void assignUserToVm(@RequestBody CustomDTOs.AssignmentsDTO assignmentsDTO, @PathVariable String id) {
        Vm vm = vmRepository.findByVmId(id).orElseThrow();
        vm.getOwners().clear();
        vm.getOwnerGroups().clear();
        for (String owner : assignmentsDTO.owners()) {
            AppUser appUser = userRepository.findByUsername(owner).orElseThrow();
            vm.getOwners().add(appUser);
        }
        vmRepository.save(vm);
        for (String group : assignmentsDTO.ownersGroups()) {
            UserGroup userGroup = userGroupRepository.findByGroupName(group).orElseThrow();
            vm.getOwnerGroups().add(userGroup);
        }
        vmRepository.save(vm);
    }

    @GetMapping("/all")
    @Transactional(readOnly = true)
    public List<CustomDTOs.ResponseVmDTO> list() {
        return getAllVms();
    }

    @GetMapping("{id}/assign/group/{groupName}")
    public void assignUserGroupToVm(@PathVariable String id, @PathVariable String groupName) {
        Vm vm = vmRepository.findByVmId(id).orElseThrow();
        UserGroup group = userGroupRepository.findByGroupName(groupName).orElseThrow();
        vm.getOwnerGroups().add(group);
        vmRepository.save(vm);
    }

    @GetMapping("/username/{username}")
    @Transactional(readOnly = true)
    public List<CustomDTOs.ResponseVmDTO> listByUserName(@PathVariable String username) {
        AppUser appUser = userRepository.findByUsername(username).orElseThrow();
        return getUserVms(appUser);
    }

    @GetMapping("/user-id/{id}")
    @Transactional(readOnly = true)
    public List<CustomDTOs.ResponseVmDTO> listByUserId(@PathVariable String id) {
        AppUser appUser = userRepository.findByUserId(id).orElseThrow();
        return getUserVms(appUser);
    }

    @GetMapping("/{id}/state")
    @Transactional(readOnly = true)
    public String getLiveStatus(@PathVariable String id) {
        Vm vm = vmRepository.findByVmId(id).orElseThrow();
        return hyperVService.getVmStateAsync(vm);
    }

    @GetMapping("/{id}")
    @Transactional(readOnly = true)
    public CustomDTOs.ResponseVmDTO getById(@PathVariable String id) {
        Vm vm = vmRepository.findByVmId(id).orElseThrow();
        String currentState = hyperVService.getVmStateAsync(vm);
        vm.setStatus(currentState);
        Vm saved = vmRepository.save(vm);
        return CustomDTOs.ResponseVmDTO.builder()
                .os(saved.getOs())
                .ip(saved.getIp())
                .cpu(saved.getCpu())
                .id(saved.getVmId())
                .hostName(saved.getHost().getName())
                .diskGb(saved.getDiskGb())
                .name(saved.getName())
                .owners(getUserNamesAsList(saved.getOwners()))
                .ownersGroups(getGroupNamesAsList(saved.getOwnerGroups()))
                .memoryMb(saved.getMemoryMb())
                .status(saved.getStatus())
                .build();
    }

    @GetMapping("/{id}/start")
    public void start(@PathVariable String id) {
        Vm vm = vmRepository.findByVmId(id).orElseThrow();
        hyperVService.startVm(vm);
    }

    @GetMapping("/{id}/restart")
    public void restart(@PathVariable String id) {
        Vm vm = vmRepository.findByVmId(id).orElseThrow();
        hyperVService.restartVm(vm);
    }

    @GetMapping("/{id}/shutdown")
    public void shutdown(@PathVariable String id) {
        Vm vm = vmRepository.findByVmId(id).orElseThrow();
        hyperVService.shutdownVm(vm);
    }


    private List<CustomDTOs.ResponseVmDTO> getUserVms(AppUser appUser) {
        List<CustomDTOs.ResponseVmDTO> result = new ArrayList<>();
        String username = appUser.getUsername();
        for (Vm vm : vmRepository.findAll()) {
            List<UserGroup> userGroups = appUser.getUserGroups();
            Set<String> vmOwnerGroupNames = vm.getOwnerGroups().stream()
                    .map(UserGroup::getGroupName)
                    .collect(Collectors.toSet());
            boolean ownedByUser = vm.getOwners().stream()
                    .anyMatch(owner -> owner.getUsername().equals(username));
            boolean ownedByGroup = userGroups != null && !userGroups.isEmpty() &&
                    userGroups.stream()
                            .anyMatch(userGroup -> vmOwnerGroupNames.contains(userGroup.getGroupName()));
            if (ownedByUser || ownedByGroup) {
                result.add(CustomDTOs.ResponseVmDTO.builder()
                        .os(vm.getOs())
                        .ip(vm.getIp())
                        .cpu(vm.getCpu())
                        .id(vm.getVmId())
                        .hostName(vm.getHost().getName())
                        .diskGb(vm.getDiskGb())
                        .name(vm.getName())
                        .owners(getUserNamesAsList(vm.getOwners()))
                        .ownersGroups(getGroupNamesAsList(vm.getOwnerGroups()))
                        .memoryMb(vm.getMemoryMb())
                        .status(vm.getStatus())
                        .build()
                );
            }
        }
        return result;
    }

    private List<CustomDTOs.ResponseVmDTO> getAllVms() {
        List<CustomDTOs.ResponseVmDTO> result = new ArrayList<>();
        for (Vm vm : vmRepository.findAll()) {
            result.add(CustomDTOs.ResponseVmDTO.builder()
                    .os(vm.getOs())
                    .ip(vm.getIp())
                    .cpu(vm.getCpu())
                    .id(vm.getVmId())
                    .hostName(vm.getHost().getName())
                    .diskGb(vm.getDiskGb())
                    .name(vm.getName())
                    .owners(getUserNamesAsList(vm.getOwners()))
                    .ownersGroups(getGroupNamesAsList(vm.getOwnerGroups()))
                    .memoryMb(vm.getMemoryMb())
                    .status(vm.getStatus())
                    .build()
            );
        }
        return result;
    }

    private List<String> getGroupNamesAsList(Set<UserGroup> ownerGroups) {
        if (ownerGroups == null || ownerGroups.isEmpty()) {
            return Collections.emptyList();
        }
        List<String> result = new ArrayList<>();
        for (UserGroup group : ownerGroups) {
            result.add(group.getGroupName());
        }
        return result;
    }


    private List<String> getUserNamesAsList(Set<AppUser> owners) {
        if (owners == null || owners.isEmpty()) {
            return Collections.emptyList();
        }
        List<String> result = new ArrayList<>();
        for (AppUser appUser : owners) {
            result.add(appUser.getUsername());
        }
        return result;
    }

}
