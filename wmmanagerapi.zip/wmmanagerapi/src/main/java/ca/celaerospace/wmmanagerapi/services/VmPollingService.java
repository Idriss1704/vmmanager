package ca.celaerospace.wmmanagerapi.services;

import lombok.AllArgsConstructor;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

@Service
@AllArgsConstructor
public class VmPollingService {

    private VmService  vmService;

    // Polls every 2 minutes (fixed rate)
    @Scheduled(fixedRate = 120000)
    public void pollVmStates() {
        System.out.println("Starting polling for VM states...");
        vmService.updateVmListOnDB();
        System.out.println("VM states polling complete.");
    }
}
