package ca.celaerospace.wmmanagerapi.controller;

import ca.celaerospace.wmmanagerapi.dto.CustomDTOs;
import ca.celaerospace.wmmanagerapi.model.UserGroup;
import ca.celaerospace.wmmanagerapi.repository.UserGroupRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/groups")
@RequiredArgsConstructor
public class UserGroupController {

    private final UserGroupRepository userGroupRepository;


    @GetMapping("/all")
    @Transactional(readOnly = true)
    public List<CustomDTOs.ResponseGroupDTO> getAllGroups() {
        List<CustomDTOs.ResponseGroupDTO> responseGroupDTOs = new ArrayList<>();
        List<UserGroup> all =  userGroupRepository.findAll();
        for (UserGroup userGroup : all) {
            responseGroupDTOs.add(CustomDTOs.ResponseGroupDTO.builder()
                    .id(userGroup.getGroupId())
                    .name(userGroup.getGroupName())
                    .build()
            );
        }
        return responseGroupDTOs;
    }


    @GetMapping("/{id}")
    @Transactional(readOnly = true)
    public CustomDTOs.ResponseGroupDTO getById(@PathVariable String id) {
        UserGroup found =  userGroupRepository.findByGroupId(id).orElseThrow();
        return CustomDTOs.ResponseGroupDTO.builder()
                .id(found.getGroupId())
                .name(found.getGroupName())
                .build();
    }

    @PostMapping
    public ResponseEntity<CustomDTOs.ResponseGroupDTO> create(@RequestBody UserGroup payload) {
        if (payload.getGroupId() != null && userGroupRepository.existsByGroupId(payload.getGroupId())) {
            return ResponseEntity.status(HttpStatus.CONFLICT).build();
        }
        UserGroup saved = userGroupRepository.save(payload);
        return ResponseEntity.status(HttpStatus.CREATED).body(CustomDTOs.ResponseGroupDTO.builder()
                .id(saved.getGroupId())
                .name(saved.getGroupName())
                .build());
    }

    @PutMapping("/{id}")
    public ResponseEntity<CustomDTOs.ResponseGroupDTO> update(@PathVariable String id, @RequestBody UserGroup payload) {
        Optional<UserGroup> opt = userGroupRepository.findByGroupId(id);
        if (opt.isEmpty()) return ResponseEntity.notFound().build();

        UserGroup g = opt.get();

        if (payload.getGroupName() != null) g.setGroupName(payload.getGroupName());

        UserGroup saved = userGroupRepository.save(g);
        return ResponseEntity.ok(CustomDTOs.ResponseGroupDTO.builder()
                .id(saved.getGroupId())
                .name(saved.getGroupName())
                .build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable String id) {
        if (!userGroupRepository.existsByGroupId(id)) {
            return ResponseEntity.notFound().build();
        }
        userGroupRepository.deleteByGroupId(id);
        return ResponseEntity.noContent().build();
    }
}
