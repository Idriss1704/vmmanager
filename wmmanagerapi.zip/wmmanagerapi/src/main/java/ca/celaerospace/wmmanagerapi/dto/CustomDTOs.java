package ca.celaerospace.wmmanagerapi.dto;


import lombok.Builder;

import java.util.List;

public class CustomDTOs {

    public record CreateUserDTO(
            String username,
            String password,
            String role,
            String fullName,
            List<String> groupNames
    ) {
    }

    public record UpdateUserDTO(
            String id,
            String username,
            String password,
            String role,
            String fullName,
            List<String> groupNames
    ) {
    }

    @Builder
    public record ResponseUserDTO(
            String id,
            String username,
            List<String> groupNames,
            String roleName,
            String fullName
    ) {
    }

    @Builder
    public record ResponseVmDTO(
            String id,
            String name,
            String status,
            Integer cpu,
            Integer memoryMb,
            Integer diskGb,
            String os,
            String ip,
            List<String> owners,
            List<String> ownersGroups,
            String hostName
    ) {
    }

    @Builder
    public record ResponseGroupDTO(
            String id,
            String name
    ) {
    }

    @Builder
    public record AssignmentsDTO(
            List<String> owners,
            List<String> ownersGroups
    ) {
    }

}
