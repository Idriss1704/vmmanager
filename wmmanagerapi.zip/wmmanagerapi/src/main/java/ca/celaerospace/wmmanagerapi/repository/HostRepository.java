package ca.celaerospace.wmmanagerapi.repository;

import ca.celaerospace.wmmanagerapi.model.Host;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.Optional;

public interface HostRepository extends MongoRepository<Host, Integer> {
  Host findByName(String name);
  boolean existsByHostId(String id);
  Optional<Host> findByHostId(String id);
  void deleteByHostId(String id);
}
