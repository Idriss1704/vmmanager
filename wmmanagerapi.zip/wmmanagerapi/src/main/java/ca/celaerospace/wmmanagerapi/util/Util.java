package ca.celaerospace.wmmanagerapi.util;

import ca.celaerospace.wmmanagerapi.model.UserGroup;

import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

public class Util {

    public static List<String> getGroupNamesFromGroups(List<UserGroup> userGroups) {
        List<String> groupNamesList;
        if (userGroups != null) {
            groupNamesList = userGroups.stream()
                    .map(UserGroup::getGroupName)
                    .collect(Collectors.toList());
        } else {
            groupNamesList = Collections.emptyList();
        }
        return groupNamesList;
    }
}
