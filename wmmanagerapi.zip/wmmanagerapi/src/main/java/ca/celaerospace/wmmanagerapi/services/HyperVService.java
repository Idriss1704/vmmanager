package ca.celaerospace.wmmanagerapi.services;

import ca.celaerospace.wmmanagerapi.model.Host;
import ca.celaerospace.wmmanagerapi.model.Vm;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.cloudsoft.winrm4j.client.WinRmClientContext;
import io.cloudsoft.winrm4j.winrm.WinRmTool;
import io.cloudsoft.winrm4j.winrm.WinRmToolResponse;
import jakarta.annotation.PreDestroy;
import org.apache.http.client.config.AuthSchemes;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.*;

@Service
@SuppressWarnings("unchecked")
public class HyperVService{

    @Value("${winrm.usehttps}")
    private boolean useHttps;

    @Value("${winrm.port}")
    private int port;

    private final WinRmClientContext winRmContext = WinRmClientContext.newInstance();
    private final ObjectMapper mapper = new ObjectMapper();

    public WinRmTool createTool(Host host) {
        System.setProperty("java.net.useSystemProxies", "false");
        System.setProperty("http.proxyHost", "");
        System.setProperty("https.proxyHost", "");
        System.setProperty("http.nonProxyHosts", host.getFqdnOrIp());

        return WinRmTool.Builder.builder(host.getFqdnOrIp(), host.getUsername(), host.getPassword())
                .port(port)
                .useHttps(useHttps)
                .disableCertificateChecks(true)
                .authenticationScheme(AuthSchemes.NTLM)
                .build();
    }

    private WinRmToolResponse execPs(Host host, String ps) {
        WinRmTool tool = createTool(host);
        WinRmToolResponse resp = tool.executePs(ps);
        if (resp.getStatusCode() != 0) {
            String msg = "WinRM/PowerShell failed (status=" + resp.getStatusCode() + "): " + resp.getStdErr();
            throw new RuntimeException(msg);
        }
        return resp;
    }

    private static String psQuote(String s) {
        return s == null ? "" : s.replace("'", "''");
    }


    public String getVmStateAsync(Vm vm) {
        Host host = vm.getHost();
        String vmName = vm.getName();
        String script = String.format("""
            $ErrorActionPreference='Stop'; $ProgressPreference='SilentlyContinue';
            $c2j = $ExecutionContext.InvokeCommand.GetCommand('ConvertTo-Json','Cmdlet');
            try {
              if (-not (Get-Module -ListAvailable -Name Hyper-V)) { Import-Module Hyper-V -ErrorAction Stop }
              $vm = Get-VM -Name '%s' -ErrorAction Stop
              $state = $vm.State.ToString()
              if ($c2j) { @{ ok=$true; state=$state } | ConvertTo-Json -Compress } else { $state }
            }
            catch {
              if ($c2j) { @{ ok=$false; error=$_.Exception.Message } | ConvertTo-Json -Compress } else { 'ERROR' }
            }
            """, vmName.replace("'", "''")); // escape single quotes safely

        WinRmToolResponse resp = execPs(host, script);
        String stdout = trimOrEmpty(resp.getStdOut());
        String stderr = trimOrEmpty(resp.getStdErr());

        if (stdout.isEmpty()) {
            throw new RuntimeException("No PowerShell output from host. stderr: " + stderr);
        }
        // Handle structured JSON output (normal case)
        if (stdout.startsWith("{")) {
            try {
                Map<String, Object> result = mapper.readValue(stdout, new TypeReference<>() {});
                Boolean ok = (Boolean) result.getOrDefault("ok", Boolean.TRUE);
                if (Boolean.FALSE.equals(ok)) {
                    throw new RuntimeException("Remote script error: " + result.get("error"));
                }
                return str(result.get("state"));
            } catch (Exception e) {
                throw new RuntimeException("Failed to parse getVmStateAsync JSON: " + stdout + " ; stderr: " + stderr, e);
            }
        }
        // Fallback (raw output, rare)
        return stdout.trim();
    }


    public Map<String, String> getVmStatesAsync(List<Vm> vms) {
        // Collecting VM names
        List<String> vmNames = vms.stream()
                .map(Vm::getName)
                .toList();

        // Create PowerShell script to get states of all VMs
        String script = String.format("""
        $ErrorActionPreference='Stop'; $ProgressPreference='SilentlyContinue';
        $c2j = $ExecutionContext.InvokeCommand.GetCommand('ConvertTo-Json','Cmdlet');
        try {
          if (-not (Get-Module -ListAvailable -Name Hyper-V)) { Import-Module Hyper-V -ErrorAction Stop }
          $vmStates = @{}
          foreach ($vmName in %s) {
            $vm = Get-VM -Name $vmName -ErrorAction Stop
            $state = $vm.State.ToString()
            $vmStates[$vmName] = $state
          }
          if ($c2j) { $vmStates | ConvertTo-Json -Compress } else { $vmStates }
        }
        catch {
          if ($c2j) { @{ ok=$false; error=$_.Exception.Message } | ConvertTo-Json -Compress } else { 'ERROR' }
        }
        """, vmNames.toString().replaceAll("[\\[\\]]", "")); // Convert List to string for PowerShell

        Host host = vms.get(0).getHost(); // Assume all VMs are on the same host
        WinRmToolResponse resp = execPs(host, script);
        String stdout = trimOrEmpty(resp.getStdOut());
        String stderr = trimOrEmpty(resp.getStdErr());

        if (stdout.isEmpty()) {
            throw new RuntimeException("No PowerShell output from host. stderr: " + stderr);
        }

        // Handle structured JSON output
        if (stdout.startsWith("{")) {
            try {
                Map<String, Object> result = mapper.readValue(stdout, new TypeReference<>() {});
                Boolean ok = (Boolean) result.getOrDefault("ok", Boolean.TRUE);
                if (Boolean.FALSE.equals(ok)) {
                    throw new RuntimeException("Remote script error: " + result.get("error"));
                }

                // Parse the VM states (Map<String, String>)
                Map<String, String> vmStates = new HashMap<>();
                Map<String, String> states = (Map<String, String>) result.get("vmStates");
                if (states != null) {
                    vmStates.putAll(states);
                }

                return vmStates;
            } catch (Exception e) {
                throw new RuntimeException("Failed to parse getVmStatesAsync JSON: " + stdout + " ; stderr: " + stderr, e);
            }
        }

        // Fallback (raw output, rare)
        return Collections.singletonMap("error", stdout.trim());
    }




    public void startVm(Vm vm) {
        Host host = vm.getHost();
        String vmName = vm.getName();

        String script = String.format("""
            $ErrorActionPreference='Stop';
            $c2j = $ExecutionContext.InvokeCommand.GetCommand('ConvertTo-Json','Cmdlet');
            try {
                if (-not (Get-Module -ListAvailable -Name Hyper-V)) { Import-Module Hyper-V -ErrorAction Stop }
                Start-VM -Name '%s' -ErrorAction Stop
                if ($c2j) { @{ ok=$true } | ConvertTo-Json -Compress } else { 'OK' }
            } catch {
                if ($c2j) { @{ ok=$false; error=$_.Exception.Message } | ConvertTo-Json -Compress } else { 'ERROR' }
            }
            """, vmName.replace("'", "''"));

        WinRmToolResponse resp = execPs(host, script);
        String stdout = trimOrEmpty(resp.getStdOut());

        if (stdout.isEmpty()) {
            throw new RuntimeException("No PowerShell output from host");
        }

        if (stdout.startsWith("{")) {
            try {
                Map<String, Object> result = mapper.readValue(stdout, new TypeReference<>() {});
                Boolean ok = (Boolean) result.getOrDefault("ok", Boolean.TRUE);
                if (!ok) {
                    throw new RuntimeException("Failed to start VM: " + result.get("error"));
                }
            } catch (Exception e) {
                throw new RuntimeException("Failed to parse JSON response: " + stdout, e);
            }
        }
    }


    public void restartVm(Vm vm) {
        Host host = vm.getHost();
        String vmName = vm.getName();

        String script = String.format("""
            $ErrorActionPreference='Stop';
            $c2j = $ExecutionContext.InvokeCommand.GetCommand('ConvertTo-Json','Cmdlet');
            try {
                if (-not (Get-Module -ListAvailable -Name Hyper-V)) { Import-Module Hyper-V -ErrorAction Stop }
                Restart-VM -Name '%s' -Force -ErrorAction Stop
                if ($c2j) { @{ ok=$true } | ConvertTo-Json -Compress } else { 'OK' }
            } catch {
                if ($c2j) { @{ ok=$false; error=$_.Exception.Message } | ConvertTo-Json -Compress } else { 'ERROR' }
            }
            """, vmName.replace("'", "''"));

        WinRmToolResponse resp = execPs(host, script);
        String stdout = trimOrEmpty(resp.getStdOut());

        if (stdout.isEmpty()) {
            throw new RuntimeException("No PowerShell output from host");
        }

        if (stdout.startsWith("{")) {
            try {
                Map<String, Object> result = mapper.readValue(stdout, new TypeReference<>() {});
                Boolean ok = (Boolean) result.getOrDefault("ok", Boolean.TRUE);
                if (!ok) {
                    throw new RuntimeException("Failed to restart VM: " + result.get("error"));
                }
            } catch (Exception e) {
                throw new RuntimeException("Failed to parse JSON response: " + stdout, e);
            }
        }
    }

    public void shutdownVm(Vm vm) {
        Host host = vm.getHost();
        String vmName = vm.getName();

        String script = String.format("""
            $ErrorActionPreference='Stop';
            $c2j = $ExecutionContext.InvokeCommand.GetCommand('ConvertTo-Json','Cmdlet');
            try {
                if (-not (Get-Module -ListAvailable -Name Hyper-V)) { Import-Module Hyper-V -ErrorAction Stop }
                Stop-VM -Name '%s' -Force -ErrorAction Stop
                if ($c2j) { @{ ok=$true } | ConvertTo-Json -Compress } else { 'OK' }
            } catch {
                if ($c2j) { @{ ok=$false; error=$_.Exception.Message } | ConvertTo-Json -Compress } else { 'ERROR' }
            }
            """, vmName.replace("'", "''"));

        WinRmToolResponse resp = execPs(host, script);
        String stdout = trimOrEmpty(resp.getStdOut());

        if (stdout.isEmpty()) {
            throw new RuntimeException("No PowerShell output from host");
        }

        if (stdout.startsWith("{")) {
            try {
                Map<String, Object> result = mapper.readValue(stdout, new TypeReference<>() {});
                Boolean ok = (Boolean) result.getOrDefault("ok", Boolean.TRUE);
                if (!ok) {
                    throw new RuntimeException("Failed to shutdown VM: " + result.get("error"));
                }
            } catch (Exception e) {
                throw new RuntimeException("Failed to parse JSON response: " + stdout, e);
            }
        }
    }

    public List<Vm> listHostVmsAsync(Host host) {

        String script = """
                $ErrorActionPreference='Stop'; $ProgressPreference='SilentlyContinue';
                $c2j = $ExecutionContext.InvokeCommand.GetCommand('ConvertTo-Json','Cmdlet');
                
                try {
                  if (-not (Get-Module -ListAvailable -Name Hyper-V)) { Import-Module Hyper-V -ErrorAction Stop }
                
                  $items = @();
                
                  Get-VM | ForEach-Object {
                    $vm = $_
                
                    # Memory (assigned or startup)
                    $memMb = 0
                    if ($vm.MemoryAssigned -and $vm.MemoryAssigned -gt 0) {
                      $memMb = [int]([math]::Round($vm.MemoryAssigned/1MB))
                    } else {
                      try {
                        $mm = Get-VMMemory -VMName $vm.Name -ErrorAction Stop
                        $memMb = [int]([math]::Round($mm.Startup/1MB))
                      } catch {}
                    }
                
                    # CPU count
                    $cpu = (Get-VMProcessor -VMName $vm.Name -ErrorAction SilentlyContinue).Count
                    if (-not $cpu) { $cpu = 0 }
                
                    # Disk sum (bytes -> GB)
                    $diskBytes = [long]0
                    $hdds = Get-VMHardDiskDrive -VMName $vm.Name -ErrorAction SilentlyContinue
                    if ($hdds) {
                      foreach ($h in $hdds) {
                        try { $vhd = Get-VHD -Path $h.Path; $diskBytes += [long]$vhd.Size } catch {}
                      }
                    }
                    $diskGb = [long]([math]::Round($diskBytes/1GB))

                    # IP Address (if running and starts with 10.)
                    $ipAddress = $null
                    if ($vm.State -eq 'Running') {
                        $vmNetworkAdapters = Get-VMNetworkAdapter -VMName $vm.Name -ErrorAction SilentlyContinue
                        foreach ($adapter in $vmNetworkAdapters) {
                            # Explicitly filter and take the first match as a string
                            $matchingIps = $adapter.IPAddresses | Where-Object { $_ -like '10.*' -and $_ -notlike '*:*' }
                            if ($matchingIps) {
                                $ipAddress = $matchingIps.ToString()
                                break
                            }
                        }
                    }
                
                    $items += [pscustomobject]@{
                      Name   = $vm.Name
                      Status = $vm.State.ToString()
                      Cpu    = [int]$cpu
                      MemMb  = [int]$memMb
                      DiskGb = [long]$diskGb
                      Os     = $null
                      Ip     = $ipAddress
                    }
                  }
                
                  if ($c2j) { @($items) | ConvertTo-Json -Compress -Depth 5 } else { '[]' }
                }
                catch {
                  if ($c2j) { @{ ok=$false; error=$_.Exception.Message } | ConvertTo-Json -Compress } else { '[]' }
                }
                """;

        WinRmToolResponse resp = execPs(host, script);
        String stdout = trimOrEmpty(resp.getStdOut());
        String stderr = trimOrEmpty(resp.getStdErr());

        if (stdout.isEmpty()) {
            throw new RuntimeException("No PowerShell output from host. stderr: " + stderr);
        }

        if (stdout.startsWith("{")) {
            Map<String, Object> maybeErr;
            try {
                maybeErr = mapper.readValue(stdout, new TypeReference<>() {
                });
            } catch (Exception ignore) {
                maybeErr = null;
            }
            if (maybeErr != null && maybeErr.containsKey("ok")) {
                Boolean ok = (Boolean) maybeErr.getOrDefault("ok", Boolean.TRUE);
                if (Boolean.FALSE.equals(ok)) {
                    throw new RuntimeException("Remote script error: " + maybeErr.get("error"));
                }
            }
        }

        List<Map<String, Object>> list;
        try {
            list = mapper.readValue(stdout, new TypeReference<>() {
            });
        } catch (Exception e) {
            throw new RuntimeException("Failed to parse listHostVms JSON: " + stdout + " ; stderr: " + stderr, e);
        }

        List<Vm> result = new ArrayList<>(list.size());
        Instant now = Instant.now();
        for (Map<String, Object> m : list) {
            Vm v = Vm.builder()
                    .name(str(m.get("Name")))
                    .status(str(m.get("Status")))
                    .cpu(numToInt(m.get("Cpu")))
                    .memoryMb(numToInt(m.get("MemMb")))
                    .diskGb(numToInt(m.get("DiskGb")))
                    .os(str(m.get("Os")))
                    .ip(str(m.get("Ip")))
                    .host(host)
                    .createdAt(now)
                    .build();
            result.add(v);
        }
        return result;
    }



    public String getVmIpAddress(Host host, String vmName) {

        String script = """
                $ErrorActionPreference='Stop'; $ProgressPreference='SilentlyContinue';
                $c2j = $ExecutionContext.InvokeCommand.GetCommand('ConvertTo-Json','Cmdlet');
                
                try {
                  if (-not (Get-Module -ListAvailable -Name Hyper-V)) { Import-Module Hyper-V -ErrorAction Stop }
                
                  $ipAddress = $null
                  $vm = Get-VM -Name '%s' -ErrorAction Stop
                
                  if ($vm.State -eq 'Running') {
                      $vmNetworkAdapters = Get-VMNetworkAdapter -VMName $vm.Name -ErrorAction SilentlyContinue
                      foreach ($adapter in $vmNetworkAdapters) {
                          # Explicitly filter for the correct IPv4 address
                          $matchingIps = $adapter.IPAddresses | Where-Object { $_ -like '10.6.*' -and $_ -notlike '*:*' }
                          if ($matchingIps) {
                              # Take the first matching IP as a string
                              $ipAddress = $matchingIps[0].ToString()
                              break
                          }
                      }
                  }
                
                  # Ensure the output is a structured object for reliable JSON parsing
                  if ($c2j) { @{ ip=$ipAddress } | ConvertTo-Json -Compress } else { Write-Output $ipAddress }
                }
                catch {
                  if ($c2j) { @{ ok=$false; error=$_.Exception.Message } | ConvertTo-Json -Compress } else { Write-Error $_.Exception.Message }
                }
                """;

        String formattedScript = String.format(script, vmName.replace("'", "''"));

        WinRmToolResponse resp = execPs(host, formattedScript);
        String stdout = trimOrEmpty(resp.getStdOut());
        String stderr = trimOrEmpty(resp.getStdErr());

        if (stdout.isEmpty()) {
            if (!stderr.isEmpty()) {
                throw new RuntimeException("Remote script error: " + stderr);
            }
            return null;
        }

        if (stdout.startsWith("{")) {
            Map<String, Object> responseMap;
            try {
                responseMap = mapper.readValue(stdout, new TypeReference<>() {
                });
            } catch (Exception e) {
                throw new RuntimeException("Failed to parse getVmIpAddress JSON: " + stdout + " ; stderr: " + stderr, e);
            }

            if (responseMap.containsKey("ok") && Boolean.FALSE.equals(responseMap.get("ok"))) {
                throw new RuntimeException("Remote script error: " + responseMap.get("error"));
            }

            return str(responseMap.get("ip"));
        }

        if (!stdout.isEmpty()) {
            return stdout.trim();
        }

        return null;
    }



    private static String str(Object o) {
        return (o == null) ? null : String.valueOf(o);
    }

    private static String trimOrEmpty(String s) {
        return s == null ? "" : s.trim();
    }

    private static Integer numToInt(Object o) {
        if (o == null) return null;
        if (o instanceof Number n) return n.intValue();
        try {
            return (int) Math.round(Double.parseDouble(o.toString()));
        } catch (Exception e) {
            return null;
        }
    }

    @PreDestroy
    public void shutdown() {
        winRmContext.shutdown();
    }
}
