package ca.celaerospace.wmmanagerapi.repository;

import ca.celaerospace.wmmanagerapi.model.UserGroup;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.List;
import java.util.Optional;

public interface UserGroupRepository extends MongoRepository<UserGroup, Integer> {

    Optional<UserGroup> findByGroupName(String name);

    List<UserGroup> findByGroupNameIn(List<String> names);

    Optional<UserGroup> findByGroupId(String id);

    boolean existsByGroupId(String id);

    void deleteByGroupId(String id);
}
