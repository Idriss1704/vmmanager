package ca.celaerospace.wmmanagerapi.services;

import ca.celaerospace.wmmanagerapi.dto.CustomDTOs;
import ca.celaerospace.wmmanagerapi.model.Host;
import ca.celaerospace.wmmanagerapi.model.Vm;
import ca.celaerospace.wmmanagerapi.repository.HostRepository;
import ca.celaerospace.wmmanagerapi.repository.VmRepository;
import lombok.AllArgsConstructor;
import lombok.Builder;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@AllArgsConstructor
@Builder
public class VmService {

    private final HostRepository hostRepository;
    private final HyperVService hyperVService;
    private final VmRepository vmRepository;

    @Async
    public void updateVmListOnDB() {
        List<Host> hosts = hostRepository.findAll();
        for (Host host : hosts) {
            List<Vm> vms = hyperVService.listHostVmsAsync(host);
            for (Vm vm : vms) {
                if ((vmRepository.existsByName(vm.getName()))) {
                    Vm found = vmRepository.findByName(vm.getName()).orElseThrow();
                    found.setStatus(vm.getStatus());
                    found.setIp(vm.getIp());
                    vmRepository.save(found);
                }else{
                    vmRepository.save(vm);
                }
            }
        }
    }

    @Async
    public void triggerVmStatusUpdates(List<CustomDTOs.ResponseVmDTO> result) {
        for (CustomDTOs.ResponseVmDTO responseVm : result) {
            Vm vm = vmRepository.findByVmId(responseVm.id()).orElseThrow();
            try {
                String vmStatus = hyperVService.getVmStateAsync(vm);
                vm.setStatus(vmStatus);
            }catch(Exception e) {

            }
            vmRepository.save(vm);
        }
    }
}
