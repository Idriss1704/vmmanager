package ca.celaerospace.wmmanagerapi.repository;

import ca.celaerospace.wmmanagerapi.model.AppUser;
import ca.celaerospace.wmmanagerapi.model.UserGroup;
import ca.celaerospace.wmmanagerapi.model.Vm;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.List;
import java.util.Optional;

public interface VmRepository extends MongoRepository<Vm, Integer> {

  Optional<Vm> findByVmId(String id);

  Optional<Vm> findByName(String name);

  boolean existsByName(String name);

  List<Vm> findByOwnersContains(AppUser appUser);

  List<Vm> findByOwnerGroupsContains(UserGroup userGroup);
}