package ca.celaerospace.wmmanagerapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WmmanagerapiApplicationTests {

    @Test
    void contextLoads() {
    }

}
